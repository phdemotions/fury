# This file is part of the standard testthat setup
library(testthat)
library(fury)

test_check("fury")
